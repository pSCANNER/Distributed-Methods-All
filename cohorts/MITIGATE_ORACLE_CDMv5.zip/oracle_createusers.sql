-- oracle_createusers.sql
-- create users for analysis (beari and analysis)

-- TODO: update passwords and tablespace names as desired

/* use this section of code for testing if creating a schema with public data
create user synpuf5 identified by synpuf5 default tablespace users;
GRANT create session TO synpuf5;
GRANT create table TO synpuf5;
GRANT create view TO synpuf5;
GRANT create any trigger TO synpuf5;
GRANT create any procedure TO synpuf5;
GRANT create sequence TO synpuf5;
GRANT create synonym TO synpuf5;
alter user synpuf5 quota unlimited on users;
*/

create user beari identified by beari default tablespace users;
GRANT create session TO beari;
GRANT create table TO beari;
GRANT create view TO beari;
GRANT create any trigger TO beari;
GRANT create any procedure TO beari;
GRANT create sequence TO beari;
GRANT create synonym TO beari;
alter user beari quota unlimited on users;

create user analysis identified by analysis default tablespace users;
GRANT create session TO analysis;
GRANT create table TO analysis;
GRANT create view TO analysis;
GRANT create any trigger TO analysis;
GRANT create any procedure TO analysis;
GRANT create sequence TO analysis;
GRANT create synonym TO analysis;
alter user analysis quota unlimited on users;