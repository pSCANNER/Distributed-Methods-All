-- dump NPI/provider cross reference table
-- all rows should have a value for NPI and provider_id
select * from NPI_list order by provider_id;

-- count visits by provider by week for drug exposures
select n.provider_id,to_char(de.drug_exposure_start_date,'yyyy/ww') ,count(distinct de.visit_occurrence_id)
from drug_exposure de, NPI_list n
where de.provider_id=n.provider_id
group by n.provider_id, to_char(de.drug_exposure_start_date,'yyyy/ww') 
order by 1,2;

-- count visits by provider by week for conditions
select n.provider_id,to_char(co.condition_start_date,'yyyy/ww') count(distinct co.visit_occurrence_id)
from condition_occurrence co, NPI_list n
where co.provider_id=n.provider_id
group by n.provider_id, to_char(co.condition_start_date,'yyyy/ww') 
order by 1,2;


-- dump weekly count of visits and meds by provider for each permutation of condition and medication present in the data
-- dumps all conditions (and flags them as in the denominator or not) but only antibacterial medications
select 
provider_id,
NPI,
c.concept_name DX,
case when x.condition_concept_id is null then ''
     when dx.concept_id is null then 'N'
     else 'Y'
end is_Trigger_DX,
x.condition_concept_id,
YRandWEEK,
d.concept_name MED,
x.drug_concept_id,
x.drug_type_concept_id,
x.Visits_w_This_Condition,
x.Visits_w_This_Med
from
(
select 
co.condition_concept_id, de.drug_concept_id, de.drug_type_concept_id,
v.provider_id, nl.NPI,
to_char(v.visit_start_date,'yyyy/ww') YRandWEEK,
count(distinct co.visit_occurrence_id) Visits_w_This_Condition,
count(distinct de.visit_occurrence_id) Visits_w_This_Med
from visit_occurrence v
inner join npi_visits_view n on v.visit_occurrence_id=n.visit_occurrence_id
inner join NPI_list nl on nl.provider_id=v.provider_id
left join condition_occurrence co on co.visit_occurrence_id=v.visit_occurrence_id
left join drug_exposure de on de.visit_occurrence_id=v.visit_occurrence_id and
-- de.drug_type_concept_id in (SELECT concept_id FROM concept_constants WHERE constant_name='PRESCRIPTION') and
de.drug_concept_id IN (SELECT medication_concept_id FROM antibacterials WHERE is_trigger = 1)
left join concept c on c.concept_id=de.drug_concept_id
where visit_start_date>'01-JAN-17'
group by co.condition_concept_id, de.drug_concept_id, de.drug_type_concept_id, v.provider_id, nl.NPI, to_char(v.visit_start_date,'yyyy/ww')
) x
left join concept c on c.concept_id=x.condition_concept_id
left join denom_DXs dx on dx.concept_id=x.condition_concept_id
left join concept d on d.concept_id=x.drug_concept_id
where x.Visits_w_This_Condition<>0 or x.Visits_w_This_Med<>0
order by 1,2,3,4,6,7,8,9;
