-- oracle_doAnalysis.sql
-- Performs the MITIGATE analysis and leaves the results in the social_norm_view

-- run this as analysis user
@@oracle_Analysis_droptables.sql
@@oracle_Analysis_createtables.sql
@@oracle_Analysis_createviews1.sql
@@oracle_Analysis_createviews2.sql
@@oracle_Analysis_createfunctions.sql

declare
-- input parameters
	cutoff_override_rate_value double precision:=.9;
-- TODO: modify these parameters as appropriate for the analysis
-- <max_days>=120
  max_days integer:=120; -- use 1200 for testing against SYNPUF5 public data instead of 120;
-- <min_denom>=35
  min_denom integer:=35;
-- <new_denom_date>='12-APR-2017'
  new_denom_date date:='12-APR-2017';
-- <min_days>=30
  min_days integer:=30; -- use 900 for testing against SYNPUF5 public data instead of 30;

-- temporary variables
  max_days_date date;
  min_days_date date;
  funcresult integer;
begin

  execute immediate 'truncate table cutoff_override_rate';
  insert into cutoff_override_rate(cutoff_override_rate)
     select cutoff_override_rate_value from dual where cutoff_override_rate_value is not null; 
  
  execute immediate 'truncate table matlized_rejected_visits_list';

  insert /*+ append */
  into matlized_rejected_visits_list
     select visit_occurrence_id from test_patient_visit_list union
     select visit_occurrence_id from ambiguous_patient_visit_list union
     select visit_occurrence_id from ambiguous_provider_visit_list union
-- we don't need this here because the expanded visits will only use visits with a drug and/or condition in the first place
--   select visit_occurrence_id from no_drug_or_cond_visit_list union
     select visit_occurrence_id from impossible_date_visit_list;
  commit;

  execute immediate 'create index matlized_rej_visits_list_idx on matlized_rejected_visits_list(visit_occurrence_id)';
  --cluster materialized_rejected_visits_list using materialized_rejected_visits_list_idx;
  execute immediate 'alter table matlized_rejected_visits_list add primary key (visit_occurrence_id)';
  --analyze materialized_rejected_visits_list;
  
  execute immediate 'truncate table materialized_expanded_visits';

  select max(visit_start_date)-max_days into max_days_date
  from expanded_visits_view;
  dbms_output.put_line(max_days_date);

  insert /*+ append */ into materialized_expanded_visits
  select /*+ parallel(8) */ e.*, 
        case when visit_start_date <= max_days_date then 1 else 0 end gtMAX_DAYS
  from expanded_visits_view e;
  
  commit;

  execute immediate 'alter table materialized_expanded_visits add primary key (visit_occurrence_id)';
  execute immediate 'create index matlized_exp_visits_person_id on materialized_expanded_visits(person_id)';
  execute immediate 'create index matlized_exp_visits_prov_id on materialized_expanded_visits(provider_id)';
  execute immediate 'create index matlized_exp_visits_start_date on materialized_expanded_visits(visit_start_date)';

-- analyze materialized_expanded_visits;
 
  execute immediate 'truncate table matlized_potential_denoms';

  insert /*+ append */ into matlized_potential_denoms
  select v.*,
     cast (null as integer) gtMIN_DENOMvisits,
     cast (null as integer) gtMIN_DAYSdays
     from ari_visits_view v
  where not exists (select 1 from suppressed_visits_view s where v.visit_occurrence_id = s.visit_occurrence_id);
  commit;

  execute immediate 'alter table matlized_potential_denoms add primary key (visit_occurrence_id)';
  execute immediate 'create index matlized_pot_denoms_person_id on matlized_potential_denoms(person_id)';
  execute immediate 'create index matlized_pot_denoms_prov_id on matlized_potential_denoms(provider_id)';
  execute immediate 'create index matlized_pot_denoms_prov_visit on matlized_potential_denoms(provider_id,visit_start_date)';
  
  select max(visit_start_date)-min_days into min_days_date
  from materialized_expanded_visits;
  dbms_output.put_line(min_days_date);

  execute immediate 'truncate table results';

-- gtMIN_DENOMvisits and gtMIN_Daysdays need to be reset to null if re-running process from here
-- update matlized_potential_denoms set gtMIN_DENOMvisits=null, gtMIN_DAYSdays=null;
  
  insert /*+ append */ into results (provider_id, denominator, min_date, max_date, new_denominators_since, new_denominators)
  select provider_id, count(*), min(visit_start_date), max(visit_start_date), new_denom_date,
      (select count(*)
       from matlized_potential_denoms
       where provider_id = d.provider_id and visit_start_date >= new_denom_date)
  from matlized_potential_denoms d
  where provider_id is not null and
   		 visit_start_date > min_days_date
/* always assume provider gets_interventions=true so we don't need this code */
/*
		and exists (select 1 
					 from subjects s, <institution>_provider_id_map m 
					 where s.subject_id = m.provider_subject_id and
			      		   m.provider_id = d.provider_id and s.gets_interventions = true)
*/
	group by provider_id;

  commit;

  update matlized_potential_denoms d set gtMIN_DENOMvisits = 0, gtMIN_DAYSdays = 0
     where exists (select 1 from results r where r.provider_id = d.provider_id and r.min_date <= d.visit_start_date);

  update matlized_potential_denoms d set gtMIN_DAYSdays = 1
     where exists (select 1 from results r where r.provider_id = d.provider_id and r.denominator >= min_denom
       and r.min_date > d.visit_start_date and d.visit_start_date <= min_days_date);
   
/* all providers should already have data in the results, they all get interventions, and we don't need to map, so this code is unnecessary */
/*
 insert into results (provider_id, denominator, min_date, max_date, new_denominators_since, new_denominators)
   select m.provider_id, 0, null, null, '<new_denom_date>', 0
   from subjects s, <institution>_provider_id_map m
   where s.subject_id = m.provider_subject_id and s.gets_interventions = true
	and not exists (select 1 from results r where r.provider_id = m.provider_id); 
*/

  commit;
  
  funcresult:=backfill_results(max_days, min_denom);

  update matlized_potential_denoms d set gtMIN_DENOMvisits = 1
  where gtMIN_DAYSdays = 0 and 
        exists (select 1 from results r where r.provider_id = d.provider_id and r.denominator >= min_denom);

  update results s set max_date = (select max(visit_start_date) from matlized_potential_denoms where provider_id = s.provider_id)
  where max_date is null;

  execute immediate('truncate table materialized_numerators');

  insert into materialized_numerators
    select provider_id,count(*)
    from actual_numerators 
    group by provider_id;
    
  update results r set numerator = nvl((select numerator from materialized_numerators n where r.provider_id = n.provider_id),0);
  
  update results set rate = cast (numerator as float) / denominator where denominator > 0;
  update results set new_denominators_since = min_date, new_denominators = denominator where min_date >= new_denom_date;
  update results set high_volume_result=case when denominator >= min_denom then 1 else 0 end;

/* DONE! */
commit;
end;
