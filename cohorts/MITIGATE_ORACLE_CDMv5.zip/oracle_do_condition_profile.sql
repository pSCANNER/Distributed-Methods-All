-- oracle_do_condition_profile.sql
-- run this as user analysis

-- generate condition profile
-- count visits by condition where there is a prescription written for a trigger medication on the antibacterials list
select /*+ index(idx_concept_concept_id) */
	case when d.concept_id is not null then 'Y' else 'N' end is_trigger_DX,
	x.condition_source_concept_id,
  c.concept_name,
  visits
from
(
    select /*+ index(c idx_condition_visit_id) */ condition_source_concept_id, count(distinct c.visit_occurrence_id) visits
  	from condition_occurrence c
    where c.visit_occurrence_id in (select distinct visit_occurrence_id
                                    from drug_exposure de
                                    where de.drug_type_concept_id=(select concept_id from concept_constants where constant_name='PRESCRIPTION') and
                                -- assumes drug exposures are using the concept correctly
                                          de.drug_concept_id in (select medication_concept_id from antibacterials where is_trigger = 1)
                                    )
    group by condition_source_concept_id
) x
inner join concept c on c.concept_id=x.condition_source_concept_id
left join denom_DXs d on d.concept_id=x.condition_source_concept_id
order by 1,4 desc,3,2;
