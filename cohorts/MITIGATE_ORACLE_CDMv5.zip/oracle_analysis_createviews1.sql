-- oracle_analysis_createviews1.sql

-- Create Analysis Views part 1

-- find visits that are related to the providers that we are interested in analyzing based on having a drug_exposure or condition_occurrence
-- this could be refined to only look for drug_exposures that are in the antibacterials list and conditions that are in the denom_DXs
create or replace view NPI_visits_view as
-- this could result in more than one row for a visit but since visits with ambiguous providers are rejected
-- it will not cause extra rows to be generated in the expanded_visits_list
select visit_occurrence_id, de.provider_id
    from drug_exposure de, NPI_list n
    where de.provider_id=n.provider_id
    union
    select visit_occurrence_id, co.provider_id
    from condition_occurrence co, NPI_list n
    where co.provider_id=n.provider_id;

begin
  declare AGE_concept integer;
  begin
    select concept_id into AGE_concept from concept_constants where constant_name='AGE';
    execute immediate('create or replace view age_info_view as
      select  /*+ index(p idx_person_id) */
       v.visit_occurrence_id,
       max(n.provider_id) provider_id,
       max(floor(o.value_as_number)) age_by_observation,
       max(floor(months_between(v.visit_start_date, 
                                               case
                                                 when year_of_birth is not null and month_of_birth is not null and day_of_birth is not null
/* old way
                                                   then to_date(year_of_birth || ''-'' || month_of_birth || ''-'' || day_of_birth,''YYYY-MM-DD'')
*/
/* new way - handle values that need a leading zero */
						   then to_date(year_of_birth || '-' || substring('0'||month_of_birth,-2,2) || '-' || substring('0'||day_of_birth,-2,2),'YYYY-MM-DD')

						 when year_of_birth is not null and month_of_birth is null or day_of_birth is null
						   then to_date(year_of_birth || '-12-31', 'YYYY-MM-DD')
                                                 else null
                                               end
                          )/12)) age_by_patient_birthday
      from visit_occurrence v
      inner join NPI_visits_view n on v.visit_occurrence_id=n.visit_occurrence_id
      left join person p on v.person_id=p.person_id
      left join observation o on o.visit_occurrence_id = v.visit_occurrence_id and
    -- Assumes Age concept is properly set up
                                o.observation_concept_id='||to_char(AGE_concept)||'
      group by v.visit_occurrence_id');
  end;
end;
