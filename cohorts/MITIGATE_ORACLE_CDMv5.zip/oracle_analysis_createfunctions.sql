-- oracle_analysis_createfunctions.sql

-- Code to gather denominators until the minimum denominator value is met for each provider
create or replace function backfill_results(max_days integer, min_denom integer) return integer as
BEGIN
declare
 earliest date;
 mydate date;
 resultcount integer;
 empty_results_table exception;
begin
-- shouldn't have an empty results table
    select count(*) into resultcount from results;
    if (resultcount < 1) then
        raise empty_results_table;
    end if;

-- find earliest visit date based on max_days prior to the latest visit start date
    select max(visit_start_date)-max_days+1 into earliest from materialized_expanded_visits;

-- compare the (day before the smallest min_date) found in the results with the maximum visit_start_date for all the data in the visits
-- use the smaller of the two dates as the starting date for the loop
    select least (
                  (select max(visit_start_date) from materialized_expanded_visits), 
                  (select min(min_date)-1 from results)
                 ) into mydate from dual;

    loop
        if (mydate < earliest) then
            return null;
        end if;
         
        update results s set
             denominator = denominator + (select count(*)
                                          from matlized_potential_denoms
                                          where provider_id = s.provider_id and
                                                visit_start_date = mydate),
             min_date = mydate
             where exists (select 1
                           from matlized_potential_denoms
                           where provider_id = s.provider_id and 
                                 visit_start_date = mydate)
                   and denominator < min_denom;
        mydate := mydate-1;
    end loop;
    
    return null;
end;
END;