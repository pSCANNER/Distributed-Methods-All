-- oracle_create_analysis_indexes.sql

-- create indexes needed for analysis that are not in the normal set of OMOP indexes
-- run this from the schema containing your OMOP instance
BEGIN
    BEGIN
       EXECUTE IMMEDIATE 'DROP INDEX analysis_visit_idx';
    EXCEPTION
       WHEN OTHERS THEN
          IF SQLCODE != -1418 THEN
             RAISE;
          END IF;
    END;

    BEGIN
      EXECUTE IMMEDIATE 'create index analysis_visit_idx on visit_occurrence(visit_occurrence_id)';
    END;

/* indexes that are used but should already exist because they are part of the standard OMOP CDM indexes
create index analysis_drug_visit_idx on drug_exposure(visit_occurrence_id);
create index analysis_condition_visit_idx on condition_occurrence(visit_occurrence_id);
create index visit_occurrence_person_id_idx on visit_occurrence(person_id);
create index drug_exposure_drug_concept_id_idx on drug_exposure(drug_concept_id);
*/

    BEGIN
       EXECUTE IMMEDIATE 'DROP INDEX visit_occ_visit_start_date_idx';
    EXCEPTION
       WHEN OTHERS THEN
          IF SQLCODE != -1418 THEN
             RAISE;
          END IF;
    END;

    BEGIN
      EXECUTE IMMEDIATE 'create index visit_occ_visit_start_date_idx on visit_occurrence(visit_start_date)';
    END;

    BEGIN
       EXECUTE IMMEDIATE 'DROP INDEX visit_occ_person_visit_idx';
    EXCEPTION
       WHEN OTHERS THEN
          IF SQLCODE != -1418 THEN
             RAISE;
          END IF;
    END;

    BEGIN
      EXECUTE IMMEDIATE 'create index visit_occ_person_visit_idx on visit_occurrence(person_id, visit_occurrence_id)';
    END;

    BEGIN
       EXECUTE IMMEDIATE 'DROP INDEX cond_occ_person_cond_occ_idx';
    EXCEPTION
       WHEN OTHERS THEN
          IF SQLCODE != -1418 THEN
             RAISE;
          END IF;
    END;

    BEGIN
      EXECUTE IMMEDIATE 'create index cond_occ_person_cond_occ_idx on condition_occurrence(person_id, condition_occurrence_id)';
    END;

    BEGIN
       EXECUTE IMMEDIATE 'DROP INDEX drug_exp_person_visit_occ_idx';
    EXCEPTION
       WHEN OTHERS THEN
          IF SQLCODE != -1418 THEN
             RAISE;
          END IF;
    END;

    BEGIN
      EXECUTE IMMEDIATE 'create index drug_exp_person_visit_occ_idx on drug_exposure(person_id, visit_occurrence_id)';
    END;

    BEGIN
       EXECUTE IMMEDIATE 'DROP INDEX obs_person_visit_occ_obs_idx';
    EXCEPTION
       WHEN OTHERS THEN
          IF SQLCODE != -1418 THEN
             RAISE;
          END IF;
    END;

    BEGIN
      EXECUTE IMMEDIATE 'create index obs_person_visit_occ_obs_idx on observation(person_id, visit_occurrence_id, observation_id)';
    END;

    BEGIN
       EXECUTE IMMEDIATE 'DROP INDEX provider_NPI_idx';
    EXCEPTION
       WHEN OTHERS THEN
          IF SQLCODE != -1418 THEN
             RAISE;
          END IF;
    END;

    BEGIN
      EXECUTE IMMEDIATE 'create index provider_NPI_idx on provider(NPI)';
    END;


/* if we need this for performance reasons on ORACLE then we need to modify the code to emulate a partial index and to grab
  the concept_id for AGE from the concept_constants table instead of hardcoding it to 4265453
    BEGIN
       EXECUTE IMMEDIATE 'DROP INDEX observation_age_idx';
    EXCEPTION
       WHEN OTHERS THEN
          IF SQLCODE != -1418 THEN
             RAISE;
          END IF;
    END;

    BEGIN
-- 4265453 is the concept for AGE.
      EXECUTE IMMEDIATE 'create index observation_age_idx on observation(observation_concept_id) where observation_concept_id = 4265453';
    END;
*/
END;
