-- oracle_create_analysis_synonyms.sql
-- run this as user analysis

-- TODO: change synpuf5 to the name of the schema containing your OMOP instance
create or replace synonym concept for synpuf5.concept;
create or replace synonym concept_relationship for synpuf5.concept_relationship;
create or replace synonym condition_occurrence for synpuf5.condition_occurrence;
create or replace synonym drug_exposure for synpuf5.drug_exposure;
create or replace synonym observation for synpuf5.observation;
create or replace synonym person for synpuf5.person;
create or replace synonym provider for synpuf5.provider;
create or replace synonym visit_occurrence for synpuf5.visit_occurrence;

create or replace synonym beari_code_sets for beari.beari_code_sets;
create or replace synonym test_patient_ids for beari.test_patient_ids;
create or replace synonym concept_constants for beari.concept_constants;
create or replace synonym antibacterials for beari.antibacterials;
create or replace synonym NPI_list for beari.NPI_list;