-- oracle_do_medication_profile.sql
-- run this from analysis user

-- generate medication profile
-- count visits by medication where there is a prescription written and the visit has a condition on the denominator list
select /*+ index(c idx_concept_concept_id) */
	case when a.medication_concept_id is not null then 'Y' else 'N' end is_trigger_Med,
	x.drug_concept_id,
  c.concept_name,
  visits
from
(
select drug_concept_id,count(distinct visit_occurrence_id) visits
from drug_exposure de
where de.drug_type_concept_id=(select concept_id from concept_constants where constant_name='PRESCRIPTION') and
-- assumes drug exposures are using the concept correctly
      de.visit_occurrence_id in (
                                  select /*+ index(c idx_condition_visit_id) */ distinct visit_occurrence_id
                                  from condition_occurrence c,denom_DXs dx
                                  where c.condition_source_concept_id=dx.concept_id
                                )
group by drug_concept_id
) x
inner join concept c on c.concept_id=x.drug_concept_id
left join antibacterials a on a.medication_concept_id=x.drug_concept_id
order by 1,4 desc,3,2;
