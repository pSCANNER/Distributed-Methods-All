-- oracle_grant_beari_selects.sql
-- run this as dba

-- TODO: replace synpuf5 schema name with the name of the schema used by your OMOP instance
grant select on synpuf5.concept to beari;
grant select on synpuf5.concept_relationship to beari;
grant select on synpuf5.provider to beari;