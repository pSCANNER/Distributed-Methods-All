-- oracle_grant_analysis_selects.sql
-- run this as dba

-- TODO: replace synpuf5 schema name with the name of the schema used by your OMOP instance
grant select on synpuf5.concept to analysis;
grant select on synpuf5.concept_relationship to analysis;
grant select on synpuf5.condition_occurrence to analysis;
grant select on synpuf5.drug_exposure to analysis;
grant select on synpuf5.observation to analysis;
grant select on synpuf5.person to analysis;
grant select on synpuf5.provider to analysis;
grant select on synpuf5.visit_occurrence to analysis;

grant select on beari.beari_code_sets to analysis;
grant select on beari.test_patient_ids to analysis;
grant select on beari.concept_constants to analysis;
grant select on beari.antibacterials to analysis;
grant select on beari.NPI_list to analysis;