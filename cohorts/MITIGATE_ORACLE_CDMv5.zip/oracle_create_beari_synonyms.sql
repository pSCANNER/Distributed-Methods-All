-- oracle_create_beari_synonyms.sql
-- run this as user beari

-- TODO: change synpuf5 to the name of the schema containing your OMOP instance
create synonym concept for synpuf5.concept;
create synonym concept_relationship for synpuf5.concept_relationship;
create synonym provider for synpuf5.provider;
