-- oracle_analysis_droptables.sql

-- drop analysis tables
BEGIN
    BEGIN
       EXECUTE IMMEDIATE 'DROP TABLE cutoff_override_rate';
    EXCEPTION
       WHEN OTHERS THEN
          IF SQLCODE != -942 THEN
             RAISE;
          END IF;
    END;

    BEGIN
       EXECUTE IMMEDIATE 'DROP TABLE matlized_rejected_visits_list';
    EXCEPTION
       WHEN OTHERS THEN
          IF SQLCODE != -942 THEN
             RAISE;
          END IF;
    END;

    BEGIN
       EXECUTE IMMEDIATE 'DROP TABLE materialized_expanded_visits';
    EXCEPTION
       WHEN OTHERS THEN
          IF SQLCODE != -942 THEN
             RAISE;
          END IF;
    END;

    BEGIN
       EXECUTE IMMEDIATE 'DROP TABLE matlized_potential_denoms';
    EXCEPTION
       WHEN OTHERS THEN
          IF SQLCODE != -942 THEN
             RAISE;
          END IF;
    END;

    BEGIN
       EXECUTE IMMEDIATE 'DROP TABLE results';
    EXCEPTION
       WHEN OTHERS THEN
          IF SQLCODE != -942 THEN
             RAISE;
          END IF;
    END;

    BEGIN
       EXECUTE IMMEDIATE 'DROP TABLE materialized_numerators';
    EXCEPTION
       WHEN OTHERS THEN
          IF SQLCODE != -942 THEN
             RAISE;
          END IF;
    END;
END;
