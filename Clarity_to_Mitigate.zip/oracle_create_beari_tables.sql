-- oracle_create_beari_tables.sql
-- run this as beari

BEGIN

    BEGIN
       EXECUTE IMMEDIATE 'DROP TABLE beari_code_sets';
    EXCEPTION
       WHEN OTHERS THEN
          IF SQLCODE != -942 THEN
             RAISE;
          END IF;
    END;

    BEGIN
      EXECUTE IMMEDIATE '
    create table beari_code_sets(
        source_code_value character varying (64),
        description character varying (255),
        vocabulary character varying(32),
        set_name character varying(32),
        concept_id integer
        )';
    END;

    BEGIN
       EXECUTE IMMEDIATE 'DROP TABLE test_patient_ids';
    EXCEPTION
       WHEN OTHERS THEN
          IF SQLCODE != -942 THEN
             RAISE;
          END IF;
    END;

    BEGIN
      EXECUTE IMMEDIATE '
    create table test_patient_ids(
        person_id integer not null
        )';
    END;

    BEGIN
       EXECUTE IMMEDIATE 'DROP TABLE concept_constants';
    EXCEPTION
       WHEN OTHERS THEN
          IF SQLCODE != -942 THEN
             RAISE;
          END IF;
    END;

/* not needed for CLARITY data
    BEGIN
      EXECUTE IMMEDIATE '
        create table concept_constants(
            constant_name character varying(32) not null,
            concept_id integer not null
            )';
    END;
*/
    
    BEGIN
       EXECUTE IMMEDIATE 'DROP TABLE antibacterials';
    EXCEPTION
       WHEN OTHERS THEN
          IF SQLCODE != -942 THEN
             RAISE;
          END IF;
    END;

/* not needed for CLARITY data
    BEGIN
      EXECUTE IMMEDIATE '
        create table antibacterials(
            is_trigger integer not null,
            medication_concept_id integer not null,
            code character varying(50),
            name character varying(255)
            )';
    END;
*/

    BEGIN
       EXECUTE IMMEDIATE 'DROP TABLE NPI_list';
    EXCEPTION
       WHEN OTHERS THEN
          IF SQLCODE != -942 THEN
             RAISE;
          END IF;
    END;

/* not needed for CLARITY data
    BEGIN
      EXECUTE IMMEDIATE '
        create table NPI_list(
            NPI varchar2(20) not null,
            provider_id integer
            )';
    END;
*/
end;
