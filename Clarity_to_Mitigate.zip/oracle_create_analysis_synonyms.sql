-- oracle_create_analysis_synonyms.sql

create or replace synonym condition_occurrence for mitigate_condition_occurrence;
create or replace synonym drug_exposure for mitigate_drug_exposure;
create or replace synonym visit_occurrence for mitigate_visit_occurrence;
