drop index x_mitigate_visit_idx;

create index x_mitigate_visit_idx on x_mitigate_tmp2_ed_all(pat_enc_csn_id);

/*
desc X_MITIGATE_TMP2_ED_ALL;

select rownum,age_category,icd10_code,dx_name,first_attending,ordering_med_provider,ordering_ua_provider,urinalysis,
dxname_1,dxname_2,dxname_3,dxname_4,dxname_5,ed_medication_name,ed_med_abx,medication,abx
from x_mitigate_tmp2_ed_all
where rownum<500;
*/

create or replace synonym mitigate_icd10 for x_mitigate_tmp2_ed_all;
create or replace synonym concept for vocab5.concept;

drop table icd10;

create table icd10 as select distinct concept_code, concept_id from concept where vocabulary_id='ICD10CM';
create index icd10_code_idx on icd10(concept_code);


create or replace view mitigate_visit_occurrence as
select visit_occurrence_id, minor_patient, visit_start_date, hadPrescription,
      case 
        when instr(longprovider_id,',')=0 then longprovider_id 
        else substr(longprovider_id, 1, instr(longprovider_id,',')+2)
        end provider_id, 
      person_id
from
(
  select distinct
  pat_enc_csn_id visit_occurrence_id,
  -- case when age_category in ('18-50','51-65','>65') then 0 else 1 end minor_patient,
  0 minor_patient,
  visit_start_date,
  maxABX hadPrescription,
  case 
  when maxMedication is not null and maxMedProvider is not null then maxMedProvider
  when maxProcedure is not null and maxOrdProvider is not null then maxOrdProvider
  else maxAttProvider
  end longprovider_id,
  pat_enc_csn_id person_id
  from
    (
    select distinct pat_enc_csn_id, max(age_category) age_category, max(trunc(hosp_admsn_time)) visit_start_date,
    coalesce(max(ED_MED_ABX), max(ABX), 'N') maxABX,
    coalesce(max(ed_medication_name),max(medication)) maxMedication,
    max(Urinalysis) maxProcedure,
    max(ordering_med_provider) maxMedProvider,
    max(ordering_ua_provider) maxOrdProvider,
    max(first_attending) maxAttProvider
    from mitigate_icd10
    group by pat_enc_csn_id
    )
);


create or replace view mitigate_condition_occurrence as
select distinct v.provider_id, v.visit_occurrence_id, co.icd10 concept_code, case when icd10.concept_id is null then -9999 else icd10.concept_id end condition_source_concept_id, v.visit_occurrence_id person_id, v.visit_start_date condition_start_date
from
(
select distinct pat_enc_csn_id visit_occurrence_id, icd10_code icd10
from mitigate_icd10
where icd10_code is not null
union
select distinct pat_enc_csn_id, dxname_1
from mitigate_icd10
where dxname_1 is not null
union
select distinct pat_enc_csn_id, dxname_2
from mitigate_icd10
where dxname_2 is not null
union
select distinct pat_enc_csn_id, dxname_3
from mitigate_icd10
where dxname_3 is not null
union
select distinct pat_enc_csn_id, dxname_4
from mitigate_icd10
where dxname_4 is not null
union
select distinct pat_enc_csn_id, dxname_5
from mitigate_icd10
where dxname_5 is not null
order by 1,2
) co
inner join mitigate_visit_occurrence v on co.visit_occurrence_id=v.visit_occurrence_id
left join icd10 on co.icd10=icd10.concept_code;

create or replace view mitigate_drug_exposure as
select distinct provider_id, visit_occurrence_id, hadPrescription, visit_occurrence_id person_id
from mitigate_visit_occurrence;
