-- oracle_analysis_createviews2.sql

-- Create Analysis Views part 2

create or replace view denom_DXs as
     select distinct concept_id
     from beari_code_sets s
     where vocabulary in ('ICD9CM','ICD10CM','SNOMED') and set_name = 'SN_DENOM';

create or replace view samevisit_suppress_DXs as
     select distinct concept_id
     from beari_code_sets s
     where vocabulary in ('ICD9CM','ICD10CM','SNOMED') and set_name in ('SAMEVISIT_SUPPRESS', 'SAME_VISIT_SUPPRESS');
     
create or replace view history_suppress_DXs as
     select distinct concept_id
     from beari_code_sets s
     where vocabulary in ('ICD9CM','ICD10CM','SNOMED') and set_name = 'HX_SUPPRESS';

create or replace view test_patient_visit_list as
  	 select v.visit_occurrence_id
  	 from visit_occurrence v
     inner join test_patient_ids t on t.person_id = v.person_id;
     
-- find visits where any drug_exposure or condition_occurence row has a different person listed than what is in the visit
create or replace view ambiguous_patient_visit_list as
select distinct v.visit_occurrence_id
  	from visit_occurrence v
  	left join drug_exposure d on d.visit_occurrence_id = v.visit_occurrence_id and
    							 d.person_id is not null and d.person_id != v.person_id
  	left join condition_occurrence c on c.visit_occurrence_id = v.visit_occurrence_id and
      								 	c.person_id is not null and c.person_id != v.person_id
  	where (d.visit_occurrence_id is not null) or (c.visit_occurrence_id is not null);

-- find visits where any drug_exposure or condition_occurrence row has more than one provider listed in the conditions and drugs
-- this could be refined to only look for drug_exposures that are in the antibacterials list and conditions that are in the denom_DXs
create or replace view ambiguous_provider_visit_list as
	select distinct /*+ index(c idx_condition_visit_id) index(d idx_drug_visit_id) */ d.visit_occurrence_id
  	from visit_occurrence v, condition_occurrence c, drug_exposure d
  	where
      v.visit_occurrence_id=c.visit_occurrence_id and v.visit_occurrence_id = d.visit_occurrence_id and
-- CDMv5 uses provider_id instead of associated_provider_id and prescribing_provider_id    
--    c.associated_provider_id is not null and c.associated_provider_id != d.prescribing_provider_id and
--    d.prescribing_provider_id is not null
	  c.provider_id != d.provider_id and d.provider_id is not null
  union
  select /*+ index(c1 idx_condition_visit_id) index(c2 idx_condition_visit_id) */ c1.visit_occurrence_id
  	from visit_occurrence v, condition_occurrence c1, condition_occurrence c2
    where
      v.visit_occurrence_id=c1.visit_occurrence_id and v.visit_occurrence_id = c2.visit_occurrence_id and
-- CDMv5 uses provider_id instead of associated_provider_id
-- 	  c1.associated_provider_id is not null and c2.associated_provider_id is not null and
--    c1.associated_provider_id != c2.associated_provider_id
	  c1.provider_id is not null and c2.provider_id is not null and c1.provider_id != c2.provider_id
  union
  select /*+ index(d1 idx_drug_visit_id) index(d2 idx_drug_visit_id) */ d1.visit_occurrence_id 
  	from visit_occurrence v, drug_exposure d1, drug_exposure d2
    where
      v.visit_occurrence_id=d1.visit_occurrence_id and v.visit_occurrence_id = d2.visit_occurrence_id and
-- CDMv5 uses provider_id instead of prescribing_provider_id
--    d1.prescribing_provider_id is not null and d2.prescribing_provider_id is not null and
--    d1.prescribing_provider_id != d2.prescribing_provider_id;
	  d1.provider_id is not null and d2.provider_id is not null and d1.provider_id != d2.provider_id;

create or replace view no_drug_or_cond_visit_list as
select v.visit_occurrence_id 
    from visit_occurrence v
    left join condition_occurrence c on c.visit_occurrence_id = v.visit_occurrence_id
    left join drug_exposure d on d.visit_occurrence_id = v.visit_occurrence_id
    where c.visit_occurrence_id is null and d.visit_occurrence_id is null;
 
-- allow for a timestamp up to 1 day in the future just to make sure we are not dealing
-- with time zone issues.
create or replace view impossible_date_visit_list as
    select distinct v.visit_occurrence_id
    from visit_occurrence v
    where v.visit_start_date > sysdate + interval '1' day;

create or replace view expanded_visits_view as
  select /*+ index(v analysis_visit_idx) index(r matlized_rej_visits_list_idx) parallel(8) */ v.visit_occurrence_id,
    v.visit_start_date,
    v.person_id,
    v.provider_id,
    v.minor_patient
    from visit_occurrence v
-- only include visits that have a drug_exposure and/or a condition_occurrence row for providers that we are interested in
-- visit_occurrence is only includes those providers when it comes from Clarity and no_drug_or_cond_visit_list rejects visits without a drug or condition
    left join matlized_rejected_visits_list r on r.visit_occurrence_id = v.visit_occurrence_id
    where r.visit_occurrence_id is null;
  
/* this code is for auditing purposes only */
create or replace view rejected_visits_view as
  select v.visit_occurrence_id,
-- don't need the visit_source_id
--  m.visit_source_id,
  v.visit_start_date,
  (select count(*) from ambiguous_patient_visit_list where visit_occurrence_id = v.visit_occurrence_id) ambiguous_patient_info,
  (select count(*) from ambiguous_provider_visit_list where visit_occurrence_id = v.visit_occurrence_id) ambiguous_provider_info,
  (select count(*) from no_drug_or_cond_visit_list where visit_occurrence_id = v.visit_occurrence_id) no_drugs_or_conditions,
  (select count(*) from impossible_date_visit_list where visit_occurrence_id = v.visit_occurrence_id) impossible_date
  from visit_occurrence v
-- don't need the visit_source_id so we don't need to do this
--  , <institution>_visit_occurrence_id_map_view m
--  where m.visit_occurrence_id = v.visit_occurrence_id 
  inner join matlized_rejected_visits_list r on v.visit_occurrence_id = r.visit_occurrence_id;
    
create or replace view display_rejected_visits as
select
  visit_occurrence_id,
-- don't need visit_source_id
--  visit_source_id,
  visit_start_date,
  ambiguous_patient_info,
  ambiguous_provider_info,
  no_drugs_or_conditions,
  impossible_date
from rejected_visits_view;
/* end of auditing code */

-- ari_visits are all visits that are not over the maximum days, person is not a minor, and have a condition that is tagged as SN_DENOM
create or replace view ari_visits_view as
   select *
   from materialized_expanded_visits v
   where gtMAX_DAYS = 0 and minor_patient = 0
   and exists (select 1
            from condition_occurrence co,denom_DXs dx
            where co.visit_occurrence_id = v.visit_occurrence_id and co.condition_source_concept_id=dx.concept_id);
     
create or replace view sameday_suppressor_view as
   select *
   from ari_visits_view v
   where exists (select 1
              from condition_occurrence co,samevisit_suppress_DXs dx
              where co.visit_occurrence_id = v.visit_occurrence_id and co.condition_source_concept_id=dx.concept_id);

create or replace view problem_list_view as 
select
   visit_occurrence_id,
   person_id,
   condition_start_date,
-- CDMv5 uses provider_id instead of associated_provider_id
--   associated_provider_id,
   provider_id,
   condition_source_concept_id
-- CDMv5 does not have condition_source_description
--   ,condition_source_description
from condition_occurrence
-- TODO consider whether anything from the CLARITY data could be considered problem list data; for now assume no
where 1=0;
/*
where condition_type_concept_id = (select concept_id
                                   from concept_constants
                                   where constant_name = 'PROBLEM_LIST');
*/

create or replace view history_suppress_detail_view as
select /*+ index(co idx_condition_visit_id) */ a.visit_occurrence_id, a.visit_start_date, v.visit_start_date hx_date, co.condition_source_concept_id hx_icd9, 'prev_visit' hx_source
     from ari_visits_view a, visit_occurrence v, condition_occurrence co, history_suppress_DXs dx
     where a.person_id = v.person_id and a.visit_start_date >= v.visit_start_date and
	 		v.visit_occurrence_id = co.visit_occurrence_id and
       		co.condition_source_concept_id = dx.concept_id
union
  select distinct n.visit_occurrence_id, n.visit_start_date, p.condition_start_date hx_date, p.condition_source_concept_id hx_icd9, 'problem_list' hx_source
   from ari_visits_view n, problem_list_view p, history_suppress_DXs s
   where n.person_id = p.person_id and
   		 n.visit_start_date >= p.condition_start_date and
   		 p.condition_source_concept_id = s.concept_id;

create or replace view historic_suppressor_view as
   select distinct a.*
   from ari_visits_view a
   where exists
     (select 1 from history_suppress_detail_view d where a.visit_occurrence_id = d.visit_occurrence_id);

create or replace view suppressed_visits_view as
   select * from sameday_suppressor_view union
   select * from historic_suppressor_view;

create or replace view actual_denominators as
  select *
  from matlized_potential_denoms d
  where visit_start_date >= (select r.min_date from results r where r.provider_id = d.provider_id);

create or replace view actual_numerators as
  select * from actual_denominators d
  where exists (select 1 from drug_exposure de where d.visit_occurrence_id=de.visit_occurrence_id and hadPrescription='Y');
/* CLARITY data already indicates whether or not it is an antibacterial prescription
   where exists
     (select 1
      from drug_exposure de, ANTIBACTERIALS a
      where d.visit_occurrence_id=de.visit_occurrence_id and
         	de.drug_type_concept_id=(select concept_id from concept_constants where constant_name='PRESCRIPTION') and
          de.drug_concept_id = a.medication_concept_id and a.is_trigger = 1
     );
*/

-- don't need any provider subject info
/*
create or replace view extended_results_view as
  select r.*, s.institution, s.recruiting_status, s.survey_status, s.ja, s.ap, s.sn, s.subject_id
  from results r, subjects s, <institution>_provider_id_map m
  where s.subject_id = m.provider_subject_id and m.provider_id = r.provider_id;
*/
create or replace view extended_results_view as
  select r.*, 1 sn
  from results r;

create or replace view highvolume_results_view as
  select *
  from extended_results_view 
  where high_volume_result=1;

create or replace view highvolume_rank_view as
  select (select count(provider_id)+1 from highvolume_results_view r2 where r2.rate < r1.rate) rank, r1.*
  from highvolume_results_view r1;
  
create or replace view highvolume_percentile_view as
   select
          (round (100 * 
             (1 - 
               (((select cast(count(*) as float) from highvolume_rank_view s2 where s2.rank < s1.rank) +
                  .5 * (select cast(count(*) as float) from highvolume_rank_view s3 where s3.rank = s1.rank)) / 
                 (select count(*) from highvolume_rank_view))))) percentile,
      s1.*
   from highvolume_rank_view s1
   order by rank;

create or replace view cutoff_rate_view as
select
  case
    when exists (select 1 from cutoff_override_rate where cutoff_override_rate is not null)
      then (select cutoff_override_rate from cutoff_override_rate)
    when exists (select 1 from highvolume_percentile_view where percentile >= 90)
      then (select max(rate) from highvolume_percentile_view where percentile >= 90)
      else (select min(rate) from highvolume_percentile_view)
    end cutoff_rate
  from dual;

create or replace view social_norms_view as
  select (select cutoff_rate from cutoff_rate_view) cutoff_rate,
  case when rate <= (select cutoff_rate from cutoff_rate_view) then 1 else 0 end TOP,
  r.*,
  (select max(visit_start_date) from materialized_expanded_visits) data_end_date
  from extended_results_view r
  where sn = 1; 
