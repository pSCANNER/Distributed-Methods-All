-- oracle_analysis_create_tables.sql

-- create analysis tables
create table cutoff_override_rate(
    cutoff_override_rate DOUBLE PRECISION,
    cutoff_data_end_date DATE
);

create table materialized_expanded_visits (
VISIT_OCCURRENCE_ID     INTEGER ,
VISIT_START_DATE        DATE,       
PERSON_ID               INTEGER, 
PROVIDER_ID             varchar2(255),     
MINOR_PATIENT           INTEGER,
gtMAX_DAYS              INTEGER
) nologging;

create table matlized_rejected_visits_list (
VISIT_OCCURRENCE_ID     INTEGER
) nologging;

create table results (
    provider_id           varchar2(255) primary key,
    denominator           INTEGER,
    numerator             INTEGER,
    rate                  FLOAT,
    min_date              DATE,
    max_date              DATE,
    new_denominators_since DATE,
    new_denominators      INTEGER,
    high_volume_result    INTEGER
);

create table matlized_potential_denoms (
VISIT_OCCURRENCE_ID          INTEGER, 
VISIT_START_DATE             DATE,       
PERSON_ID                    INTEGER, 
PROVIDER_ID                  varchar2(255),     
MINOR_PATIENT                INTEGER,     
GTMAX_DAYS                   INTEGER,
GTMIN_DENOMvisits            INTEGER,
GTMIN_DAYSdays               INTEGER
);

create table materialized_numerators (
provider_id   varchar2(255) PRIMARY KEY,
numerator     INTEGER
);