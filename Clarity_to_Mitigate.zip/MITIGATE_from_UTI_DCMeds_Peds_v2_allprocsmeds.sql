drop table X_MITIGATE_TMP2_ADT_ALL;

create table
   X_MITIGATE_TMP2_ADT_ALL
  as

select distinct
            ROW_NUMBER () 
                   OVER 
                   (
                      PARTITION BY pe.PAT_ENC_CSN_ID
                      ORDER BY adt.EFFECTIVE_TIME
                   ) as ROW_ID,
            adt.EVENT_ID EventID,
            pe.PAT_ID,
            pt.PAT_MRN_ID,
            pt.PAT_NAME,
            pt.BIRTH_DATE,
            adt.PAT_ENC_CSN_ID,
            pe.HOSP_ADMSN_TIME,
            pe.HOSP_DISCH_TIME,
            zcet.NAME Event,
            pe.ADT_ARRIVAL_TIME Event_In_Time,
            cd.DEPARTMENT_NAME,
            adt.DEPARTMENT_ID,
            outid.Event_Out,
            case when (outid.Event_Out_Time is null) --In case Patient not discharged need to value with end search date
                        then sysdate --'09/10/2015 23:59:59' 
                        else outid.Event_Out_Time
                        end as Event_Out_Time,
            outid.DEPARTMENT_NAME OUT_DEPARTMENT,
            outid.DEPARTMENT_ID OUT_DEPARTMENT_ID
from      CLARITY_ADT adt
join      PAT_ENC_HSP pe on
              adt.PAT_ENC_CSN_ID = pe.PAT_ENC_CSN_ID
join      PATIENT pt on
              pe.PAT_ID = pt.PAT_ID
left join CLARITY_DEP cd on 
              adt.DEPARTMENT_ID = cd.DEPARTMENT_ID
left join CLARITY_BED cb on
              adt.BED_CSN_ID = cb.BED_CSN_ID
left join CLARITY_ROM cr on
              adt.ROOM_CSN_ID = cr.ROOM_CSN_ID
left join ZC_EVENT_TYPE zcet on 
              adt.EVENT_TYPE_C = zcet.EVENT_TYPE_C
left join (
            select distinct
                      adt.EVENT_ID,
                      adt.NEXT_OUT_EVENT_ID,
                      zcet.NAME Event_Out,
                      cd.DEPARTMENT_NAME,
                      adt.DEPARTMENT_ID,
                      adt.EFFECTIVE_TIME Event_Out_Time
            from      CLARITY_ADT adt
            join      PAT_ENC_HSP pe on
                          adt.PAT_ENC_CSN_ID = pe.PAT_ENC_CSN_ID
            left join CLARITY_DEP cd on 
                          adt.DEPARTMENT_ID = cd.DEPARTMENT_ID
            left join CLARITY_BED cb on 
                          adt.BED_ID = cb.BED_ID
            left join ZC_EVENT_TYPE zcet on 
                          adt.EVENT_TYPE_C = zcet.EVENT_TYPE_C
            where     pe.ADT_ARRIVAL_TIME >= '01/01/2017' 
--                      and pe.ADT_ARRIVAL_TIME < '01/01/2017'  
                      and pe.ED_EPISODE_ID IS NOT NULL 
                      and adt.EVENT_TYPE_C in ('2','4')
                      and adt.EVENT_SUBTYPE_C <> 2
            ) outid on adt.NEXT_OUT_EVENT_ID = outid.EVENT_ID
where 
          pe.ADT_ARRIVAL_TIME >= '01/01/2017' 
--          and pe.ADT_ARRIVAL_TIME < '01/01/2017'  
          and pe.ED_EPISODE_ID IS NOT NULL 
          and adt.EVENT_TYPE_C in ('1','3')
          and adt.EVENT_SUBTYPE_C <> 2
order by adt.PAT_ENC_CSN_ID, pe.ADT_ARRIVAL_TIME
;
commit;

drop table X_MITIGATE_TMP2_ED_DC;

create table
   X_MITIGATE_TMP2_ED_DC
  as
  
SELECT
            edrow.ROW_ID,
            edrow.EventID,
            edrow.PAT_ID,
            edrow.PAT_MRN_ID,
            edrow.PAT_NAME,
            edrow.BIRTH_DATE,
            edrow.PAT_ENC_CSN_ID,
            edrow.HOSP_ADMSN_TIME,
            edrow.HOSP_DISCH_TIME,
            edrow.Event,
            edrow.Event_In_Time,
            edrow.DEPARTMENT_NAME,
            edrow.DEPARTMENT_ID,
            nextrow.Event_Out,
            nextrow.Event_Out_Time,
            nextrow.OUT_DEPARTMENT,
            nextrow.OUT_DEPARTMENT_ID
FROM
            X_MITIGATE_TMP2_ADT_ALL edrow
JOIN
            X_MITIGATE_TMP2_ADT_ALL nextrow on
                edrow.PAT_ENC_CSN_ID = nextrow.PAT_ENC_CSN_ID
                and edrow.ROW_ID = (nextrow.ROW_ID + 1)
WHERE
            edrow.ROW_ID = (
                            select max(edrow1.row_id) + 1
                            from  X_MITIGATE_TMP2_ADT_ALL edrow1
                            where edrow1.DEPARTMENT_ID = 100001090 --ED
                            and edrow.PAT_ENC_CSN_ID = edrow1.PAT_ENC_CSN_ID
                            )
;
commit;

drop table X_MITIGATE_TMP2_ED_ADT_TIMES;

create table
   X_MITIGATE_TMP2_ED_ADT_TIMES
  as

select distinct
            adt.EVENT_ID EventID,
            pe.PAT_ID,
            pt.PAT_MRN_ID,
            pt.PAT_NAME,
            pt.BIRTH_DATE,
            adt.PAT_ENC_CSN_ID,
            pe.HOSP_ADMSN_TIME,
            pe.HOSP_DISCH_TIME,
            zcet.NAME Event,
            pe.ADT_ARRIVAL_TIME Event_In_Time,
            cd.DEPARTMENT_NAME,
            cr.ROOM_NAME,
            cb.BED_LABEL,
            adt.DEPARTMENT_ID,
            outid.Event_Out,
            case when (outid.Event_Out_Time is null) --In case Patient not discharged need to value with end search date
                        then sysdate --'09/10/2015 23:59:59' 
                        else outid.Event_Out_Time
                        end as Event_Out_Time
from      CLARITY_ADT adt
join      PAT_ENC_HSP pe on
              adt.PAT_ENC_CSN_ID = pe.PAT_ENC_CSN_ID
join      PATIENT pt on
              pe.PAT_ID = pt.PAT_ID
left join CLARITY_DEP cd on 
              adt.DEPARTMENT_ID = cd.DEPARTMENT_ID
left join CLARITY_BED cb on
              adt.BED_CSN_ID = cb.BED_CSN_ID
left join CLARITY_ROM cr on
              adt.ROOM_CSN_ID = cr.ROOM_CSN_ID
left join ZC_EVENT_TYPE zcet on 
              adt.EVENT_TYPE_C = zcet.EVENT_TYPE_C
left join (
            select distinct
                      adt.EVENT_ID,
                      adt.NEXT_OUT_EVENT_ID,
                      zcet.NAME Event_Out,
                      cd.DEPARTMENT_NAME,
                      cb.BED_LABEL,
                      adt.EFFECTIVE_TIME Event_Out_Time
            from      CLARITY_ADT adt
            join      PAT_ENC_HSP pe on
                          adt.PAT_ENC_CSN_ID = pe.PAT_ENC_CSN_ID
            left join CLARITY_DEP cd on 
                          adt.DEPARTMENT_ID = cd.DEPARTMENT_ID
            left join CLARITY_BED cb on 
                          adt.BED_ID = cb.BED_ID
            left join ZC_EVENT_TYPE zcet on 
                          adt.EVENT_TYPE_C = zcet.EVENT_TYPE_C
            where     pe.ADT_ARRIVAL_TIME >= '01/01/2017' 
--                      and pe.ADT_ARRIVAL_TIME < '01/01/2017'  
                      and pe.ED_EPISODE_ID IS NOT NULL 
                      and adt.EVENT_TYPE_C in ('2','4')
                      and cd.DEPARTMENT_ID in (100001024,100001090, 18, 100900288, 100001025, 100900106)
                      and adt.EVENT_SUBTYPE_C <> 2
            ) outid on adt.NEXT_OUT_EVENT_ID = outid.EVENT_ID
where 
          pe.ADT_ARRIVAL_TIME >= '01/01/2017'
--          and pe.ADT_ARRIVAL_TIME < '01/01/2017'  
          and pe.ED_EPISODE_ID IS NOT NULL 
          and adt.EVENT_TYPE_C in ('1','3')
          and cd.DEPARTMENT_ID in (100001024,100001090, 18, 100900288, 100001025, 100900106)
          and adt.EVENT_SUBTYPE_C <> 2
order by adt.PAT_ENC_CSN_ID, pe.ADT_ARRIVAL_TIME
;
commit;

drop table X_MITIGATE_TMP2_ED_ADT;

create table
   X_MITIGATE_TMP2_ED_ADT
  as

select
          PAT_ENC_CSN_ID,
          min(Event_In_Time) Event_In_Time,
          max(Event_Out_Time) Event_Out_Time
from
          X_MITIGATE_TMP2_ED_ADT_TIMES
group by
          PAT_ENC_CSN_ID
;

drop table X_MITIGATE_TMP2_ED_MEDS;

create table
   X_MITIGATE_TMP2_ED_MEDS
  as
SELECT DISTINCT
              adt.PAT_ENC_CSN_ID,
              ce.NAME Ordering_Med_Provider,
--              cs.PROV_NAME Ordering_Med_Provider,
              cm.NAME Medication,
              f.FREQ_NAME,
              dr.NAME Route,
              tc.NAME THERA_CLASS,
	      case when tc.THERA_CLASS_C=41 then 'Y' else 'N' end ABX,
              pc.NAME PHARM_CLASS,
              psc.NAME PHARM_SUBCLASS,
              zc.NAME Action,
              omi.NUMBER_OF_DOSES,
              case
                  when f.DISPLAY_NAME like 'Daily%' then omi.NUMBER_OF_DOSES
                  when f.DISPLAY_NAME = 'QAM' then omi.NUMBER_OF_DOSES
                  when f.DISPLAY_NAME = 'Q24H' then omi.NUMBER_OF_DOSES  
                  when f.DISPLAY_NAME = 'QAM' then omi.NUMBER_OF_DOSES 
                  when f.DISPLAY_NAME = 'every other day' then omi.NUMBER_OF_DOSES/0.5
                  when f.DISPLAY_NAME = 'MoWeFr' then omi.NUMBER_OF_DOSES/0.5
                  when f.DISPLAY_NAME like 'Q48%' then omi.NUMBER_OF_DOSES/0.5
                  when f.DISPLAY_NAME = 'Q12H' then omi.NUMBER_OF_DOSES/2
                  when f.DISPLAY_NAME like 'BID%' then omi.NUMBER_OF_DOSES/2
                  when f.DISPLAY_NAME = 'Q6H' then omi.NUMBER_OF_DOSES/4
                  when f.DISPLAY_NAME like 'QID%' then omi.NUMBER_OF_DOSES/4
                  when f.DISPLAY_NAME like 'Q8H%' then omi.NUMBER_OF_DOSES/3
                  when f.DISPLAY_NAME like 'TID%' then omi.NUMBER_OF_DOSES/3
                  when f.DISPLAY_NAME = 'Q4H' then omi.NUMBER_OF_DOSES/6                  
              end as DURATION_DAYS,
              om.REFILLS
FROM
          X_MITIGATE_TMP2_ED_ADT adt
JOIN      ED_IEV_PAT_INFO ei on 
              adt.PAT_ENC_CSN_ID = ei.PAT_ENC_CSN_ID 
JOIN      SNAPSHOT_ORDERS so on 
              ei.EVENT_ID = so.EVENT_ID
JOIN      ORDER_MED om on
              so.SNAPSHOT_ORD_ID = om.ORDER_MED_ID 
JOIN      CLARITY_MEDICATION cm on 
              om.MEDICATION_ID = cm.MEDICATION_ID
JOIN      ORDER_MEDINFO omi on
              om.ORDER_MED_ID = omi.ORDER_MED_ID
LEFT JOIN	ED_IEV_EVENT_INFO eii on
              so.EVENT_ID = eii.EVENT_ID
              and so.SNAPSHOT_EVENT_LINE = eii.LINE 
LEFT JOIN CLARITY_EMP ce on
              om.ORD_CREATR_USER_ID = ce.USER_ID  
--LEFT JOIN CLARITY_SER cs on
--              om.AUTHRZING_PROV_ID = cs.PROV_ID
LEFT JOIN	LEV_MAP lm ON 
              eii.EVENT_TYPE = lm.CID    
LEFT JOIN	ZC_DISPENSE_ROUTE dr on
              om.MED_ROUTE_C = dr.DISPENSE_ROUTE_C	
LEFT JOIN	ZC_MED_UNIT mu on
              om.HV_DOSE_UNIT_C = mu.DISP_QTYUNIT_C	
LEFT JOIN	IP_FREQUENCY f on
              om.HV_DISCR_FREQ_ID = f.FREQ_ID
LEFT JOIN ZC_SNAPSHOT_DISP zc on 
              so.SNAPSHOT_DISP_C = zc.SNAPSHOT_DISP_C
LEFT JOIN ZC_THERA_CLASS tc on
              cm.THERA_CLASS_C = tc.THERA_CLASS_C 
LEFT JOIN ZC_PHARM_CLASS pc on
              cm.PHARM_CLASS_C = pc.PHARM_CLASS_C   
LEFT JOIN ZC_PHARM_SUBCLASS psc on
              cm.PHARM_SUBCLASS_C = psc.PHARM_SUBCLASS_C               
WHERE
--          tc.THERA_CLASS_C = 41 --Abx
--          and 
so.SNAPSHOT_DISP_C = 1 --Start
          and	(eii.LINE is null
                OR eii.LINE = 
                CASE       
                   WHEN lm.CID is null THEN
                (
                  coalesce((select max(mr.LINE)
                  from ED_IEV_EVENT_INFO mr                  
                  where eii.EVENT_ID = mr.EVENT_ID and mr.EVENT_TYPE = '35240'),
                  (select max(mr.LINE)
                  from ED_IEV_EVENT_INFO mr
                  where eii.EVENT_ID = mr.EVENT_ID and mr.EVENT_TYPE = '35230')
                  )
                )
                ELSE  
                (
                  coalesce((select max(mr.LINE)
                  from LEV_MAP,ED_IEV_EVENT_INFO mr
                  where eii.EVENT_ID = mr.EVENT_ID and mr.EVENT_TYPE = LEV_MAP.CID and LEV_MAP.RECORD_ID = '35240'),
                  (select max(mr.LINE)
                  from LEV_MAP,ED_IEV_EVENT_INFO mr
                  where eii.EVENT_ID = mr.EVENT_ID and mr.EVENT_TYPE = LEV_MAP.CID and LEV_MAP.RECORD_ID = '35230')
                  )
                )
              END) 
;  
commit;

drop table X_MITIGATE_TMP2_ED_WBC;

create table
   X_MITIGATE_TMP2_ED_WBC
  as
SELECT
        pe.PAT_ENC_CSN_ID,
        case
            when ord.ORD_VALUE = '>100' then 100
            when ord.ORD_VALUE = '12-25' then 15
            when ord.ORD_VALUE = '25-50' then 30
            when ord.ORD_VALUE = '26-100' then 75
            when ord.ORD_VALUE = '50-100' then 80
            when ord.ORD_VALUE = '6-12' then 8
            when ord.ORD_VALUE = '6-25' then 15
        else ord.ORD_NUM_VALUE end as ORD_VALUE
FROM    PAT_ENC_HSP pe
JOIN    ORDER_PROC op on
            pe.PAT_ENC_CSN_ID = op.PAT_ENC_CSN_ID 
JOIN    ORDER_RESULTS ord on
            op.ORDER_PROC_ID = ord.ORDER_PROC_ID
JOIN    CLARITY_EAP eap on
            op.PROC_ID = eap.PROC_ID
JOIN    CLARITY_COMPONENT cc on
            ord.COMPONENT_ID = cc.COMPONENT_ID
            and cc.COMPONENT_ID in (2818)  --WBC
JOIN    X_MITIGATE_TMP2_ED_ADT adt on
            op.PAT_ENC_CSN_ID = adt.PAT_ENC_CSN_ID
            and op.ORDER_INST between adt.Event_In_Time and adt.Event_Out_Time
WHERE
        pe.ADT_ARRIVAL_TIME >= '01/01/2017'
--        and pe.ADT_ARRIVAL_TIME < '01/01/2017'  
        and pe.ED_EPISODE_ID IS NOT NULL 
        and eap.PROC_NAME like '%URINALYSIS%'
        and op.ORDER_STATUS_C <> 4 --Cancelled
GROUP BY
        pe.PAT_ENC_CSN_ID,
        case
            when ord.ORD_VALUE = '>100' then 100
            when ord.ORD_VALUE = '12-25' then 15
            when ord.ORD_VALUE = '25-50' then 30
            when ord.ORD_VALUE = '26-100' then 75
            when ord.ORD_VALUE = '50-100' then 80
            when ord.ORD_VALUE = '6-12' then 8
            when ord.ORD_VALUE = '6-25' then 15
        else ord.ORD_NUM_VALUE end
;
commit;

drop table X_MITIGATE_TMP2_ED_PROC;

create table
   X_MITIGATE_TMP2_ED_PROC
  as
SELECT    PAT_ENC_CSN_ID,ORDER_INST,ORDER_PROC_ID,"1","2","3","4","5","6"	
FROM
  (
  SELECT DISTINCT
          pe.PAT_ENC_CSN_ID, op.ORDER_PROC_ID, op.ORDER_INST, ordr.LINE_COMMENT, ordr.RESULTS_COMP_CMT
  FROM
          PAT_ENC_HSP pe
  JOIN    ORDER_PROC op on
              pe.PAT_ENC_CSN_ID = op.PAT_ENC_CSN_ID
  JOIN    CLARITY_EAP eap on
              op.PROC_ID = eap.PROC_ID
  JOIN    ORDER_RESULTS ord on
              op.ORDER_PROC_ID = ord.ORDER_PROC_ID
  JOIN    X_MITIGATE_TMP2_ED_ADT adt on
              op.PAT_ENC_CSN_ID = adt.PAT_ENC_CSN_ID
              and op.ORDER_INST between adt.Event_In_Time and adt.Event_Out_Time + 24
  JOIN    ORDER_RES_COMP_CMT ordr on
              ord.ORDER_PROC_ID = ordr.ORDER_ID
  WHERE
          pe.ADT_ARRIVAL_TIME >= '01/01/2017'
--          and pe.ADT_ARRIVAL_TIME < '01/01/2017'  
          and pe.ED_EPISODE_ID IS NOT NULL 
          and eap.PROC_NAME like 'CULTURE URINE%'
          and op.ORDER_STATUS_C <> 4 --Cancelled
          and ordr.LINE_COMMENT between 1 and 6
          and ordr.RESULTS_COMP_CMT is not null
  )
PIVOT
  (MIN(RESULTS_COMP_CMT)
  FOR LINE_COMMENT in (1,2,3,4,5,6)
  )
;
commit;

drop table X_MITIGATE_TMP2_ED_ALL;

create table
   X_MITIGATE_TMP2_ED_ALL
  as
SELECT DISTINCT
              pt.PAT_MRN_ID,
              pt.PAT_NAME,
              pt.BIRTH_DATE,
              sex.NAME Gender,
              case
                  when race.PAT_ID is null then 'Unknown'
              else race.RACE end as RACE,
              round((pe.HOSP_ADMSN_TIME - pt.BIRTH_DATE)/365,0) Age,
              case
                    when round((pe.HOSP_ADMSN_TIME - pt.BIRTH_DATE)/365,0) < 2 then '0-24 Months'
                    when round((pe.HOSP_ADMSN_TIME - pt.BIRTH_DATE)/365,0) between 2 and 17 then '2-17'
                    when round((pe.HOSP_ADMSN_TIME - pt.BIRTH_DATE)/365,0) between 18 and 50 then '18-50'
                    when round((pe.HOSP_ADMSN_TIME - pt.BIRTH_DATE)/365,0) between 51 and 65 then '51-65'
                    when round((pe.HOSP_ADMSN_TIME - pt.BIRTH_DATE)/365,0) > 65 then '>65'
              end as Age_Category,
              pe.PAT_ENC_CSN_ID,
              dx.HSP_ACCOUNT_ID,
              pe.HOSP_ADMSN_TIME, 
              pe.HOSP_DISCH_TIME, 
              EXTRACT (YEAR FROM pe.HOSP_DISCH_TIME) Year,
              EXTRACT (MONTH FROM pe.HOSP_DISCH_TIME) Month,
              icd9.CODE ICD9_CODE,
              icd10.CODE ICD10_CODE,
              edg.DX_NAME,
              case 
                  when EDDispo.PAT_ENC_CSN_ID is not null then EDDispo.ED_DC_Dispo 
              else eps.NAME end as DCStatus_ER,
              cs.PROV_NAME First_Attending,
              meds.Ordering_Med_Provider,
              ua.Ordering_UA_Provider,
              ua.PROC_NAME Urinalysis,
--              ua.ABNORMAL_YN UA_Abnormal_Order,
              case
                  when bact.PAT_ENC_CSN_ID is not null OR leuk.PAT_ENC_CSN_ID is not null OR nitr.PAT_ENC_CSN_ID is not null OR wbc.PAT_ENC_CSN_ID is not null
              then 'Y' else 'N' end as UA_Abnormal_Lab,
              case
                  when proc.PAT_ENC_CSN_ID is not null then 'Y'
              else 'N' end as Culture_Ordered,
              proc."1" CultureResult_1,
              proc."2" CultureResult_2,
              proc."3" CultureResult_3,
              proc."4" CultureResult_4,
              proc."5" CultureResult_5,
              proc."6" CultureResult_6,
              rsn."1" RsnVisit_1,
              rsn."2" RsnVisit_2,
              rsn."3" RsnVisit_3,
              dxname."1" DxName_1,
              dxname."2" DxName_2,
              dxname."3" DxName_3,
              dxname."4" DxName_4,
              dxname."5" DxName_5,
              case
                  when dxpyelo.PAT_ENC_CSN_ID is not null then 'Y' else null
              end as Pyelo,
              case
                  when dxcys.PAT_ENC_CSN_ID is not null then 'Y' else null
              end as Cystitis,
              case
                  when dxpreg.PAT_ENC_CSN_ID is not null then 'Y' else null
              end as Pregnancy_UTI,
              edmeds.ED_MEDICATION_NAME,
              edmeds.ABX ED_MED_ABX,
              meds.Medication,
              meds.ABX,
              meds.FREQ_NAME,
              meds.Route,
              meds.THERA_CLASS,
              meds.PHARM_CLASS,
              meds.PHARM_SUBCLASS,
              meds.Action,
              meds.NUMBER_OF_DOSES,
              meds.DURATION_DAYS,
              meds.REFILLS,
              case
                  when meds.PHARM_CLASS = 'QUINOLONES' and meds.DURATION_DAYS > 7 then 'Y'
                  when meds.PHARM_CLASS = 'QUINOLONES' and meds.DURATION_DAYS < 8 then 'N'
              else null end as Inappropriate_Fluoroquinolone
FROM  
          HSP_ACCOUNT ha
JOIN      HSP_ACCT_DX_LIST dx on
              ha.HSP_ACCOUNT_ID = dx.HSP_ACCOUNT_ID 
JOIN      HSP_ACCOUNT_3 ha3 on 
              dx.HSP_ACCOUNT_ID = ha3.HSP_ACCOUNT_ID
JOIN      PAT_ENC_HSP pe on
              ha3.CODED_CONTACT_CSN = pe.PAT_ENC_CSN_ID
JOIN      PATIENT pt on 
              pe.PAT_ID = pt.PAT_ID
JOIN      CLARITY_EDG edg on
              dx.DX_ID = edg.DX_ID 
JOIN		  CLARITY_ADT adt ON 
              pe.DIS_EVENT_ID = adt.EVENT_ID    
JOIN		  HSP_ATND_PROV ap on
              pe.PAT_ENC_CSN_ID = ap.PAT_ENC_CSN_ID
              and ap.LINE = (Select MIN(LINE)
                      From HSP_ATND_PROV ap1
                      where
                      ap.PAT_ENC_CSN_ID = ap1.PAT_ENC_CSN_ID)	
JOIN		  CLARITY_SER cs on
              ap.PROV_ID = cs.PROV_ID 
LEFT JOIN EDG_CURRENT_ICD9 icd9 on
              edg.DX_ID = icd9.DX_ID  
--              and icd9.CODE = '486' --CAP (Community Acquired Pneumonia)
--              and icd9.CODE in ('590.1','590.11','590.8','595.0','595.9','599.0') --UTI
                and icd9.CODE ='xyzzx' -- don't want any returned
LEFT JOIN EDG_CURRENT_ICD10 icd10 on
              edg.DX_ID = icd10.DX_ID    
--              and icd10.CODE = 'J18.9' --CAP (Community Acquired Pneumonia)
--              and icd10.CODE in ('N10','N30.0','N39.0') --UTI
-- include acute respiratory infection
and (
icd10.code like 'A00%' 
or icd10.code like 'A01%' 
or icd10.code like 'A02%' 
or icd10.code like 'A03%' 
or icd10.code like 'A04%' 
or icd10.code like 'A05%' 
or icd10.code like 'A06%'
or icd10.code like 'A07%' 
or icd10.code like 'A09%' 
or icd10.code like 'A15%' 
or icd10.code like 'A17%' 
or icd10.code like 'A18%' 
or icd10.code like 'A19%'
or icd10.code like 'A2%' 
or icd10.code like 'A3%' 
or icd10.code like 'A4%' 
or icd10.code like 'A46%' 
or icd10.code like 'A5%' 
or icd10.code like 'A64%'
or icd10.code like 'A65%' 
or icd10.code like 'A66%' 
or icd10.code like 'A67%' 
or icd10.code like 'A68%' 
or icd10.code like 'A69%' 
or icd10.code like 'A7%'
or icd10.code like 'B5%' 
or icd10.code like 'B6%' 
or icd10.code like 'B7%' 
or icd10.code like 'B95%' 
or icd10.code like 'B96%' 
or icd10.code like 'G0%' 
or icd10.code like 'H00%' 
or icd10.code like 'H05%' 
or icd10.code like 'H10%' 
or icd10.code like 'H15%' 
or icd10.code like 'H16%' 
or icd10.code like 'H20%'
or icd10.code like 'H440%' 
or icd10.code like 'H441%' 
or icd10.code like 'H60%' 
or icd10.code like 'H610%' 
or icd10.code like 'H65%' 
or icd10.code like 'H66%'
or icd10.code like 'H67%' 
or icd10.code like 'H70%' 
or icd10.code like 'H73%' 
or icd10.code like 'H75%' 
or icd10.code like 'I00%' 
or icd10.code like 'I01%'
or icd10.code like 'I311%' 
or icd10.code like 'I33%' 
or icd10.code like 'I38%' 
or icd10.code like 'J00%' 
or icd10.code like 'J01%' 
or icd10.code like 'J02%'
or icd10.code like 'J03%' 
or icd10.code like 'J040%' 
or icd10.code like 'J041%' 
or icd10.code like 'J042%' 
or icd10.code like 'J043%' 
or icd10.code like 'J050%' 
or icd10.code like 'J051%' 
or icd10.code like 'J06%' 
or icd10.code like 'J09%' 
or icd10.code like 'J10%'
or icd10.code like 'J11%' 
or icd10.code like 'J12%' 
or icd10.code like 'J13%' 
or icd10.code like 'J14%' 
or icd10.code like 'J15%'
or icd10.code like 'J16%' 
or icd10.code like 'J18%' 
or icd10.code like 'J200%' 
or icd10.code like 'J201%' 
or icd10.code like 'J202%' 
or icd10.code like 'J203%' 
or icd10.code like 'J204%' 
or icd10.code like 'J205%' 
or icd10.code like 'J206%' 
or icd10.code like 'J207%'
or icd10.code like 'J208%' 
or icd10.code like 'J209%' 
or icd10.code like 'J21%' 
or icd10.code like 'J22%' 
or icd10.code like 'J30%' 
or icd10.code like 'J31%' 
or icd10.code like 'J32%' 
or icd10.code like 'J340%' 
or icd10.code like 'J36%' 
or icd10.code like 'J390%' 
or icd10.code like 'J391%' 
or icd10.code like 'J40%' 
or icd10.code like 'J41%' 
or icd10.code like 'J42%' 
or icd10.code like 'J43%'
or icd10.code like 'J44%' 
or icd10.code like 'J45%' 
or icd10.code like 'J47%' 
or icd10.code like 'J80%' 
or icd10.code like 'J84%'
or icd10.code like 'J85%' 
or icd10.code like 'J86%' 
or icd10.code like 'K02%' 
or icd10.code like 'K04%' 
or icd10.code like 'K05%' 
or icd10.code like 'K112%' 
or icd10.code like 'K113%' 
or icd10.code like 'K12%' 
or icd10.code like 'K35%' 
or icd10.code like 'K36%' 
or icd10.code like 'K37%' 
or icd10.code like 'K38%' 
or icd10.code like 'K50%' 
or icd10.code like 'K51%' 
or icd10.code like 'K55%' 
or icd10.code like 'K57%' 
or icd10.code like 'K61%' 
or icd10.code like 'K63%' 
or icd10.code like 'K65%' 
or icd10.code like 'K66%' 
or icd10.code like 'K67%' 
or icd10.code like 'K68%' 
or icd10.code like 'K750%' 
or icd10.code like 'K80%' 
or icd10.code like 'K81%' 
or icd10.code like 'K83%' 
or icd10.code like 'K85%' 
or icd10.code like 'K92%' 
or icd10.code like 'K94%' 
or icd10.code like 'K95%' 
or icd10.code like 'L00%' 
or icd10.code like 'L01%' 
or icd10.code like 'L02%' 
or icd10.code like 'L03%' 
or icd10.code like 'L04%' 
or icd10.code like 'L05%' 
or icd10.code like 'L08%' 
or icd10.code like 'L10%' 
or icd10.code like 'L11%' 
or icd10.code like 'L12%' 
or icd10.code like 'L13%' 
or icd10.code like 'L14%' 
or icd10.code like 'L40%' 
or icd10.code like 'L51%' 
or icd10.code like 'L52%' 
or icd10.code like 'L600%' 
or icd10.code like 'L70%' 
or icd10.code like 'L73%' 
or icd10.code like 'L88%' 
or icd10.code like 'L89%' 
or icd10.code like 'L97%' 
or icd10.code like 'M00%' 
or icd10.code like 'M01%' 
or icd10.code like 'M46%' 
or icd10.code like 'M60%' 
or icd10.code like 'M70%' 
or icd10.code like 'M86%' 
or icd10.code like 'N10%' 
or icd10.code like 'N12%' 
or icd10.code like 'N151%' 
or icd10.code like 'N30%' 
or icd10.code like 'N34%' 
or icd10.code like 'N390%' 
or icd10.code like 'N41%' 
or icd10.code like 'N45%' 
or icd10.code like 'N476%' 
or icd10.code like 'N481%' 
or icd10.code like 'N49%' 
or icd10.code like 'N61%' 
or icd10.code like 'N7%' 
or icd10.code like 'O23%' 
or icd10.code like 'O411%' 
or icd10.code like '085%' 
or icd10.code like 'O86%' 
or icd10.code like 'O91%' 
or icd10.code like 'O98%' 
or icd10.code like 'P36%' 
or icd10.code like 'P37%' 
or icd10.code like 'P38%' 
or icd10.code like 'P39%' 
or icd10.code like 'P77%' 
or icd10.code like 'R36%' 
or icd10.code like 'R7881%' 
or icd10.code like 'R8271%' 
or icd10.code like 'S31%' 
or icd10.code like 'S41%' 
or icd10.code like 'S51%' 
or icd10.code like 'S61%' 
or icd10.code like 'S71%' 
or icd10.code like 'T802%' 
or icd10.code like 'T826%' 
or icd10.code like 'T827%' 
or icd10.code like 'T845%' 
or icd10.code like 'T846%' 
or icd10.code like 'T847%' 
or icd10.code like 'T84%' 
or icd10.code like 'T85%' 
or icd10.code like 'T87%' 
or icd10.code like 'T88%' 
or icd10.code like 'W53%' 
or icd10.code like 'W54%' 
or icd10.code like 'W55%' 
or icd10.code like 'W56%' 
or icd10.code like 'W57%' 
or icd10.code like 'W59%' 
or icd10.code like 'W60%' 
or icd10.code like 'W61%'
or icd10.code like 'W62%' 
or icd10.code like 'Y28%' 
or icd10.code like 'Y83%' 
or icd10.code like 'Z11%' 
or icd10.code like 'Z20%' 
or icd10.code like 'Z21%' 
or icd10.code like 'Z22%'
)
LEFT JOIN X_MITIGATE_TMP2_ED_MEDS meds on              
              pe.PAT_ENC_CSN_ID = meds.PAT_ENC_CSN_ID
LEFT JOIN
          (
          SELECT
                    pt.PAT_ID,
                    zpr.NAME RACE
          FROM
                    PATIENT pt
          JOIN      PATIENT_RACE pr on
                        pt.PAT_ID = pr.PAT_ID
          JOIN      ZC_PATIENT_RACE zpr on
                        pr.PATIENT_RACE_C = zpr.PATIENT_RACE_C
          WHERE     pr.LINE = (Select MAX(pr1.LINE)
                            From PATIENT_RACE pr1
                            where
                            pr.PAT_ID = pr1.PAT_ID) 
          ) race on pt.PAT_ID = race.PAT_ID
LEFT JOIN 
          (
          SELECT
                  pe.PAT_ENC_CSN_ID,
                  cm.NAME ED_MEDICATION_NAME,
		  case when cm.THERA_CLASS_C=41 then 'Y' else 'N' end ABX
          FROM    PAT_ENC_HSP pe
          JOIN    ORDER_MED om on
                      pe.PAT_ENC_CSN_ID = om.PAT_ENC_CSN_ID 
          JOIN		MAR_ADMIN_INFO mai on
                      om.ORDER_MED_ID = mai.ORDER_MED_ID
          JOIN    CLARITY_MEDICATION cm on 
                      om.MEDICATION_ID = cm.MEDICATION_ID
          JOIN    X_MITIGATE_TMP2_ED_ADT adt on
                      mai.MAR_ENC_CSN = adt.PAT_ENC_CSN_ID
                      and mai.TAKEN_TIME between adt.Event_In_Time and adt.Event_Out_Time
          WHERE
                  pe.ADT_ARRIVAL_TIME >= '01/01/2017'
--                  and pe.ADT_ARRIVAL_TIME < '01/01/2017'  
                  and pe.ED_EPISODE_ID IS NOT NULL 
                  and om.ORDER_STATUS_C <> 4 --Cancelled
--                  and cm.THERA_CLASS_C = 41 --Abx
                  and mai.MAR_ACTION_C = 1 --Given
          GROUP BY
                  pe.PAT_ENC_CSN_ID,
                  cm.NAME
          ) edmeds on pe.PAT_ENC_CSN_ID = edmeds.PAT_ENC_CSN_ID               
LEFT JOIN 
          (
          SELECT
                  pe.PAT_ENC_CSN_ID,
                  eap.PROC_NAME,
                  cs.PROV_NAME Ordering_UA_Provider,
                  op.ABNORMAL_YN
          FROM    PAT_ENC_HSP pe
          JOIN    ORDER_PROC op on
                      pe.PAT_ENC_CSN_ID = op.PAT_ENC_CSN_ID 
          JOIN    ORDER_RESULTS ord on
                      op.ORDER_PROC_ID = ord.ORDER_PROC_ID
          JOIN    CLARITY_EAP eap on
                      op.PROC_ID = eap.PROC_ID
          JOIN    CLARITY_SER cs on
                      op.AUTHRZING_PROV_ID = cs.PROV_ID
          JOIN    X_MITIGATE_TMP2_ED_ADT adt on
                      op.PAT_ENC_CSN_ID = adt.PAT_ENC_CSN_ID
                      and op.ORDER_INST between adt.Event_In_Time and adt.Event_Out_Time
          WHERE
                  pe.ADT_ARRIVAL_TIME >= '01/01/2017'
--                  and pe.ADT_ARRIVAL_TIME < '01/01/2017'  
                  and pe.ED_EPISODE_ID IS NOT NULL 
--                  and eap.PROC_NAME like '%URINALYSIS%'
                  and op.ORDER_STATUS_C <> 4 --Cancelled
          GROUP BY
                  pe.PAT_ENC_CSN_ID,
                  eap.PROC_NAME,
                  cs.PROV_NAME,
                  op.ABNORMAL_YN
          ) ua on pe.PAT_ENC_CSN_ID = ua.PAT_ENC_CSN_ID
LEFT JOIN
          (
          SELECT DISTINCT
                     PAT_ENC_CSN_ID,ORDER_PROC_ID,ORDER_INST,"1","2","3","4","5","6"	
          FROM
                     X_MITIGATE_TMP2_ED_PROC a
          WHERE
                    a.ORDER_PROC_ID = (Select min(a1.ORDER_PROC_ID)
                                      From  X_MITIGATE_TMP2_ED_PROC a1
                                      where a.PAT_ENC_CSN_ID = a1.PAT_ENC_CSN_ID)                       
          ) proc on pe.PAT_ENC_CSN_ID = proc.PAT_ENC_CSN_ID                  
LEFT JOIN 
          (
          SELECT
                  pe.PAT_ENC_CSN_ID,
                  ord.ORD_VALUE
          FROM    PAT_ENC_HSP pe
          JOIN    ORDER_PROC op on
                      pe.PAT_ENC_CSN_ID = op.PAT_ENC_CSN_ID 
          JOIN    ORDER_RESULTS ord on
                      op.ORDER_PROC_ID = ord.ORDER_PROC_ID
          JOIN    CLARITY_EAP eap on
                      op.PROC_ID = eap.PROC_ID
                      and eap.PROC_NAME like '%URINALYSIS%'
          JOIN    CLARITY_COMPONENT cc on
                      ord.COMPONENT_ID = cc.COMPONENT_ID
                      and cc.COMPONENT_ID in (1527) --BACTERIA/HPF
          JOIN    X_MITIGATE_TMP2_ED_ADT adt on
                      op.PAT_ENC_CSN_ID = adt.PAT_ENC_CSN_ID
                      and op.ORDER_INST between adt.Event_In_Time and adt.Event_Out_Time
          WHERE
                  pe.ADT_ARRIVAL_TIME >= '01/01/2017'
--                  and pe.ADT_ARRIVAL_TIME < '01/01/2017'  
                  and pe.ED_EPISODE_ID IS NOT NULL 
                  and op.ORDER_STATUS_C <> 4 --Cancelled
                  and ord.ORD_VALUE in ('MANY','MODERATE')
          GROUP BY
                  pe.PAT_ENC_CSN_ID,
                  ord.ORD_VALUE    
          ) bact on pe.PAT_ENC_CSN_ID = bact.PAT_ENC_CSN_ID 
LEFT JOIN 
          (
          SELECT
                  pe.PAT_ENC_CSN_ID,
                  ord.ORD_VALUE
          FROM    PAT_ENC_HSP pe
          JOIN    ORDER_PROC op on
                      pe.PAT_ENC_CSN_ID = op.PAT_ENC_CSN_ID 
          JOIN    ORDER_RESULTS ord on
                      op.ORDER_PROC_ID = ord.ORDER_PROC_ID
          JOIN    CLARITY_EAP eap on
                      op.PROC_ID = eap.PROC_ID
                      and eap.PROC_NAME like '%URINALYSIS%'
          JOIN    CLARITY_COMPONENT cc on
                      ord.COMPONENT_ID = cc.COMPONENT_ID
                      and cc.COMPONENT_ID in (1549) --LEUK. ESTERASE
          JOIN    X_MITIGATE_TMP2_ED_ADT adt on
                      op.PAT_ENC_CSN_ID = adt.PAT_ENC_CSN_ID
                      and op.ORDER_INST between adt.Event_In_Time and adt.Event_Out_Time
          WHERE
                  pe.ADT_ARRIVAL_TIME >= '01/01/2017'
--                  and pe.ADT_ARRIVAL_TIME < '01/01/2017'  
                  and pe.ED_EPISODE_ID IS NOT NULL 
                  and ord.ORD_VALUE <> 'Negative'
                  and op.ORDER_STATUS_C <> 4 --Cancelled
          GROUP BY
                  pe.PAT_ENC_CSN_ID,
                  ord.ORD_VALUE    
          ) leuk on pe.PAT_ENC_CSN_ID = leuk.PAT_ENC_CSN_ID   
LEFT JOIN 
          (
          SELECT
                  pe.PAT_ENC_CSN_ID,
                  ord.ORD_VALUE
          FROM    PAT_ENC_HSP pe
          JOIN    ORDER_PROC op on
                      pe.PAT_ENC_CSN_ID = op.PAT_ENC_CSN_ID 
          JOIN    ORDER_RESULTS ord on
                      op.ORDER_PROC_ID = ord.ORDER_PROC_ID
          JOIN    CLARITY_EAP eap on
                      op.PROC_ID = eap.PROC_ID
                      and eap.PROC_NAME like '%URINALYSIS%'
          JOIN    CLARITY_COMPONENT cc on
                      ord.COMPONENT_ID = cc.COMPONENT_ID
                      and cc.COMPONENT_ID in (1554) --NITRITE URINE
          JOIN    X_MITIGATE_TMP2_ED_ADT adt on
                      op.PAT_ENC_CSN_ID = adt.PAT_ENC_CSN_ID
                      and op.ORDER_INST between adt.Event_In_Time and adt.Event_Out_Time
          WHERE
                  pe.ADT_ARRIVAL_TIME >= '01/01/2017'
--                  and pe.ADT_ARRIVAL_TIME < '01/01/2017'  
                  and pe.ED_EPISODE_ID IS NOT NULL 
                  and ord.ORD_VALUE = 'POSITIVE'
                  and op.ORDER_STATUS_C <> 4 --Cancelled
          GROUP BY
                  pe.PAT_ENC_CSN_ID,
                  ord.ORD_VALUE    
          ) nitr on pe.PAT_ENC_CSN_ID = nitr.PAT_ENC_CSN_ID             
LEFT JOIN 
          (
          SELECT
                  PAT_ENC_CSN_ID,
                  ORD_VALUE
          FROM
                  X_MITIGATE_TMP2_ED_WBC
          WHERE
                  ORD_VALUE > 5
          GROUP BY
                  PAT_ENC_CSN_ID,
                  ORD_VALUE
          ) wbc on pe.PAT_ENC_CSN_ID = wbc.PAT_ENC_CSN_ID           
LEFT JOIN
          (
          SELECT
                  PAT_ENC_CSN_ID,
                  case 
                      when DEPARTMENT_ID in (100001108,100001068,100001091,100001092,100001093,100001049,100001054,100001055,100001056,100001057,100001048,100001106) then 'ICU Admission'
                  else 'Admission' end as ED_DC_Dispo
          FROM
                  X_MITIGATE_TMP2_ED_DC
          ) EDDispo on pe.PAT_ENC_CSN_ID = EDDispo.PAT_ENC_CSN_ID 
LEFT JOIN	
          (
          SELECT    PAT_ENC_CSN_ID,"1","2","3"	
          FROM
            (
            SELECT	pe.PAT_ENC_CSN_ID,rsn.LINE, rsn.ENC_REASON_NAME
            FROM	  PAT_ENC_HSP pe
            JOIN	  PAT_ENC_RSN_VISIT rsn on
                      pe.PAT_ENC_CSN_ID = rsn.PAT_ENC_CSN_ID
            JOIN    X_MITIGATE_TMP2_ED_ADT adt on 
                      pe.PAT_ENC_CSN_ID = adt.PAT_ENC_CSN_ID
            WHERE
                    rsn.LINE between 1 and 3
            )
          PIVOT
            (MIN(ENC_REASON_NAME)
            FOR LINE in (1,2,3)
            )
          ) rsn on pe.PAT_ENC_CSN_ID = rsn.PAT_ENC_CSN_ID  
LEFT JOIN
          (
          SELECT    PAT_ENC_CSN_ID,UPDATE_DATE,"1","2","3","4","5","6"	
          FROM
            (
            SELECT	pe.PAT_ENC_CSN_ID, dx.UPDATE_DATE, dx.LINE, edg.DX_NAME, code
            FROM	  PAT_ENC_HSP pe
            JOIN	  PAT_ENC_DX dx on
                      pe.PAT_ENC_CSN_ID = dx.PAT_ENC_CSN_ID
            JOIN    ENC_DX_EDIT_TRAIL edit on
                      pe.PAT_ENC_CSN_ID = edit.PAT_ENC_CSN_ID
            JOIN	  CLARITY_EDG edg on
                      dx.DX_ID = edg.DX_ID
            JOIN    EDG_CURRENT_ICD10 icd on
                      edg.DX_ID = icd.DX_ID
            JOIN    X_MITIGATE_TMP2_ED_ADT adt on
                      pe.PAT_ENC_CSN_ID = adt.PAT_ENC_CSN_ID
                      and edit.DX_EDIT_INST between adt.Event_In_Time and adt.Event_Out_Time
            WHERE
                    dx.LINE between 1 and 6
            )
          PIVOT
            (MIN(CODE)
            FOR LINE in (1,2,3,4,5,6)
            )
          ) dxname on pe.PAT_ENC_CSN_ID = dxname.PAT_ENC_CSN_ID
LEFT JOIN
          (
          SELECT    PAT_ENC_CSN_ID,UPDATE_DATE,"1","2","3","4","5","6"	
          FROM
            (
            SELECT	pe.PAT_ENC_CSN_ID, dx.UPDATE_DATE, dx.LINE, edg.DX_NAME
            FROM	  PAT_ENC_HSP pe
            JOIN	  PAT_ENC_DX dx on
                      pe.PAT_ENC_CSN_ID = dx.PAT_ENC_CSN_ID
            JOIN    ENC_DX_EDIT_TRAIL edit on
                      pe.PAT_ENC_CSN_ID = edit.PAT_ENC_CSN_ID
            JOIN	  CLARITY_EDG edg on
                      dx.DX_ID = edg.DX_ID
            JOIN    EDG_CURRENT_ICD10 icd on
                      edg.DX_ID = icd.DX_ID
            JOIN    X_MITIGATE_TMP2_ED_ADT adt on
                      pe.PAT_ENC_CSN_ID = adt.PAT_ENC_CSN_ID
                      and edit.DX_EDIT_INST between adt.Event_In_Time and adt.Event_Out_Time
            WHERE
                    dx.LINE between 1 and 6
                    and icd.CODE in ('N10','N11','N12','N20.9','N13.6')
            )
          PIVOT
            (MIN(DX_NAME)
            FOR LINE in (1,2,3,4,5,6)
            )
          ) dxpyelo on pe.PAT_ENC_CSN_ID = dxpyelo.PAT_ENC_CSN_ID   
LEFT JOIN
          (
          SELECT    PAT_ENC_CSN_ID,UPDATE_DATE,"1","2","3","4","5","6"	
          FROM
            (
            SELECT	pe.PAT_ENC_CSN_ID, dx.UPDATE_DATE, dx.LINE, edg.DX_NAME
            FROM	  PAT_ENC_HSP pe
            JOIN	  PAT_ENC_DX dx on
                      pe.PAT_ENC_CSN_ID = dx.PAT_ENC_CSN_ID
            JOIN    ENC_DX_EDIT_TRAIL edit on
                      pe.PAT_ENC_CSN_ID = edit.PAT_ENC_CSN_ID
            JOIN	  CLARITY_EDG edg on
                      dx.DX_ID = edg.DX_ID
            JOIN    EDG_CURRENT_ICD10 icd on
                      edg.DX_ID = icd.DX_ID
            JOIN    X_MITIGATE_TMP2_ED_ADT adt on
                      pe.PAT_ENC_CSN_ID = adt.PAT_ENC_CSN_ID
                      and edit.DX_EDIT_INST between adt.Event_In_Time and adt.Event_Out_Time
            WHERE
                    dx.LINE between 1 and 6
                    and icd.CODE like ('N30%')
            )
          PIVOT
            (MIN(DX_NAME)
            FOR LINE in (1,2,3,4,5,6)
            )
          ) dxcys on pe.PAT_ENC_CSN_ID = dxcys.PAT_ENC_CSN_ID     
LEFT JOIN
          (
          SELECT    PAT_ENC_CSN_ID,UPDATE_DATE,"1","2","3","4","5","6"	
          FROM
            (
            SELECT	pe.PAT_ENC_CSN_ID, dx.UPDATE_DATE, dx.LINE, edg.DX_NAME
            FROM	  PAT_ENC_HSP pe
            JOIN	  PAT_ENC_DX dx on
                      pe.PAT_ENC_CSN_ID = dx.PAT_ENC_CSN_ID
            JOIN    ENC_DX_EDIT_TRAIL edit on
                      pe.PAT_ENC_CSN_ID = edit.PAT_ENC_CSN_ID
            JOIN	  CLARITY_EDG edg on
                      dx.DX_ID = edg.DX_ID
            JOIN    EDG_CURRENT_ICD10 icd on
                      edg.DX_ID = icd.DX_ID
            JOIN    X_MITIGATE_TMP2_ED_ADT adt on
                      pe.PAT_ENC_CSN_ID = adt.PAT_ENC_CSN_ID
                      and edit.DX_EDIT_INST between adt.Event_In_Time and adt.Event_Out_Time
            WHERE
                    dx.LINE between 1 and 6
                    and icd.CODE in ('O23.0','O23.1')
            )
          PIVOT
            (MIN(DX_NAME)
            FOR LINE in (1,2,3,4,5,6)
            )
          ) dxpreg on pe.PAT_ENC_CSN_ID = dxpreg.PAT_ENC_CSN_ID               
LEFT JOIN ZC_ER_PAT_STS_HA eps on
              ha.PATIENT_STATUS_C = eps.ER_PAT_STS_HA_C 
LEFT JOIN	ZC_SEX sex on
              pt.SEX_C = sex.RCPT_MEM_SEX_C
WHERE     
          pe.ADT_ARRIVAL_TIME >= '01/01/2017' 
--          and pe.ADT_ARRIVAL_TIME < '01/01/2017'  
          and pe.ED_EPISODE_ID IS NOT NULL
          and dx.LINE <= 3 
          and ha.CODING_STATUS_C = 4 
          and adt.EVENT_TYPE_C = 2
          and (icd9.DX_ID is not null OR icd10.DX_ID is not null)
--          and (
--              icd.CODE in ('N10','N11','N12','N20.9','N13.6')
--              OR icd.CODE like ('N30%')
--              OR icd.CODE like ('N39%')
--              OR icd.CODE in ('O23.0','O23.1')
--              )
ORDER BY  pt.PAT_NAME, pe.PAT_ENC_CSN_ID  --, cm.NAME
;
commit;

select * from X_MITIGATE_TMP2_ED_ALL;

            

